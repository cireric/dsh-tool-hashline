# Orchestrator 人格提示词精简验收

日期：2026-10-28。范围：按用户要求，以 KISS 与奥卡姆剃刀原则审视并直接优化人格提示词。保留当前工作树已有的联合修复成果，不重做 watchdog、编辑工具或部署架构。

## 判断与改动

**有必要优化，已完成文本精简。** 原文件同时承担人格、协议手册、故障历史、部署说明和工具参数示例，重复且有冲突。当前保留一份直接可读的 persona，不引入提示词模块、加载器或额外模型调用。

| 项目 | 修改前 | 修改后 |
|---|---:|---:|
| 字符数（归一化 LF） | 19054 | 6550 |
| 空白分隔词数 | 3232 | 969 |
| 行数（按换行分割） | 93 | 58 |

字符减少约 **66%**；词数不是模型 Token 数，本轮没有测实际 Token 或模型效果。

保留的核心约定：任务端到端负责、明确则推进/关键多解则澄清/必需信息缺失则问、每请求首次正式回复的 Intent、问题专用程序及等待、实际 SDK/Hashline 路径、已有授权与用户改动保护、按需委派、部分副作用恢复、证据与交接。

删除或合并：

- 重复的声明/授权/等待禁令和“只写标记”的长解释；保留模型需要执行的最短协议。
- 与问题专用 run_code 冲突的“提问回复不能带程序”文字。
- 以当前输入必须含特定 implement 动词作为行动前提的机械措辞，改为依据已有授权和实际范围判断。
- 缺少适用条件的委派成本倍数、另一 preset 的安装建议及故障会话操作步骤。
- 从 SDK 重复抄录的固定路径、参数对象、编辑程序与工具返回字段示例，改为读取当前 SDK、canonical value 和 nextAction。
- 重复的 hard blocks、绝对“只跑一次”验证指令、长篇 session 环境说明；保留终态证据、变化后补测及不编造 session id 的要求。

首句身份、`{{model}}` 插值、Phase 0 入口和 Intent 形状保持兼容。人格不再声称格式合格等于理解正确，也不把提示词写出的要求当作已经证明的运行时保证。

## 修改面与资源身份

- [人格提示词](../../presets/ptc-hashline/personas/orchestrator.md)。
- [提示组装契约](../../tests/integration/persona-intent-gate-contract.spec.ts)：保留五个测试组，改为检查必要约定与冲突，减少固定示例/原句绑定。
- [资源校验](../../scripts/check-preset.mjs)：本次相对保存的修改前文件仅更新 persona 摘要，不改 watchdog 摘要、配置判据或资源检查。

persona 归一化 SHA-256：`c5a94e18d606d0ac84db3213868627ffb543bb410b951f003b98eeb2cd5cb3dd`。

工作树原有大量联合修复改动。本轮在 `.scratch/persona-kiss/2026-10-28/` 保存修改前 persona、契约测试、check-preset、工作树 Diff，以及隔离候选的 406 文件身份清单；没有 reset、stash 或覆盖原有成果。该本地目录被忽略，不随 clone 交付。

## 验证结果

| 命令/场景 | 退出码与结果 | 覆盖范围 |
|---|---|---|
| 修改前运行三个 persona spec | 0，17 PASS | 当前基线的提示组装、覆盖与宿主作用域 |
| 更新契约断言、仍使用旧 persona | 1，4 FAIL / 1 PASS | 新断言能拒绝旧冲突/静态示例等形状；不是模型效果实验 |
| 精简后重跑三个 persona spec | 0，17 PASS | 实际 registry/scope/interpolation 组装与人格保留 |
| `node scripts/check-preset.mjs` | 0，PASS | preset 不变量与资源摘要 |
| 隔离候选 `pnpm install --offline --frozen-lockfile` | 0 | 锁定依赖、pnpm 11.28.5；未安装到日常 profile |
| 隔离候选 `pnpm test:delivery --out ..\delivery-final` | 0，21 PASS / 0 FAIL / 9 BLOCKED | 打包安装、真实 launcher 装配、交付工作流及九道门禁 |
| `git diff --check` | 0 | 最终工作树 whitespace 检查；既有行尾提示不算产品失败 |

最终交付运行记录中的九道门禁均 exit 0：`pnpm build`、`pnpm -r check`、`pnpm check:tests`、`pnpm test:unit`、`pnpm test:integration`、`pnpm test:ptc`、`pnpm test:compat`、`pnpm check:preset`、`pnpm test:profile`。

9 个未执行的交付 ID 保持 BLOCKED：INC-02/03/04、UPG-02/05/08/09/10/11，不将这些计作 PASS。

原始证据：`.scratch/persona-kiss/2026-10-28/` 下 `persona-before.log`、`persona-red.log`、`persona-after.log`、`metrics.json`、`review.json`、`source-manifest.json`、`candidate-install-elevated.log`、`delivery-final.log` 和 `delivery-final/2026-10-28-delivery-acceptance-{report.md,summary.json}`。正式结论与命令保存在本文，原始日志保持本地。

### 首轮失败与后续处理

普通沙箱的 pnpm 启动器未能从其隔离缓存解析锁定的 pnpm 版本；使用获准的隔离验证执行环境后，离线安装同一锁定版本成功。

首次交付运行 exit 1：复制出的候选尚未构建即打包，安装产物缺 tool-read/dist；另有两项新集成测试要求 `.tmp` 父目录先存在。该轮最终门禁已生成构建产物，在副本创建空 `.tmp` 后，以新输出目录重新运行，同一源码组合得到最终 exit 0。未为消除失败修改产品或测试；原首轮 `delivery/` 与 `delivery.log` 保留，不改写为从未失败。

## 结论边界

本轮证明提示内容更短、必要约定仍进入实际 assembly，且该最终源码组合通过所列工程门禁。没有执行真实模型，不能声称歧义识别、工具采用或成本已经改善；原联合修复的真实 UI、模型与其他未覆盖验收不因本轮通过而自动闭合。

构建、打包与安装均在隔离副本/一次性 DSH_HOME 中进行；日常宿主未重启、未切换、未发布。只复核 persona 本次差异，不把原有联合修复全部归为本次交付。
