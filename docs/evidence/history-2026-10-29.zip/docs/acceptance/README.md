# 历史证据与旧计划

这里按主题查阅历史，不维护当前待办。最新结论见[当前状态](2026-10-23-current-status-and-evidence-index.md)；以下阶段描述只代表当时。不同轮次的报告及 JSON 保持原路径与原结果。

## 近期变更顺序

- 意图门：10-27 七票 → [10-28 声明修复](2026-10-28-declaration-repair-engineering.md) → [联合工程记录](2026-10-28-joint-repair-engineering.md) → [独立核验](2026-10-28-joint-goals-independent-verification.md) → [persona 精简](2026-10-28-orchestrator-persona-simplification.md) → [取消格式门的本地验证](../../.scratch/intent-advisory-fix/verification.json) → [每条用户输入重新声明的本地验证](../../.scratch/intent-followup-fix/verification.json)。后两项为本地证据，不随 clone 交付。
- P3：曾选择[路线 1](../plans/2026-10-28-p3-route1-client-presentation-design.md)，后因取消格式门停止；旧展示设计不是当前待完成项。
- 工具判读：独立核验中的反例未因取消格式门自动关闭；旧缓存上限、修复次数与首次 Failed 要求须先判断是否已被新契约取代。

## 按主题查旧记录

<details>
<summary>展开历史主题、计划与报告（原导航保留，仅供追溯）</summary>

| 主题 | 原始规格、计划与报告 |
|---|---|
| PTC Hashline 工具路径修复（2026-10-28 计划） | [工具路径计划](../plans/2026-10-28-ptc-hashline-tool-routing-repair-plan.md)、[联合运行手册](../plans/2026-10-28-joint-host-acceptance-runbook.md)、[联合工程验收](2026-10-28-joint-repair-engineering.md) |
| 意图门后续修复（2026-10-28 计划，**与工具路径联合实施**） | [修复实施计划](../plans/2026-10-28-intent-gate-repair-implementation-plan.md)、[联合工程验收](2026-10-28-joint-repair-engineering.md)、[设计稿](../plans/2026-10-28-p3-route1-client-presentation-design.md)、[运行手册](../plans/2026-10-28-joint-host-acceptance-runbook.md)、[真实模型联合清单](../plans/2026-10-28-joint-real-model-evaluation-manifest.md)、[机器可读案例](../plans/2026-10-28-joint-real-model-cases.json)、[采集与对账操作单](../plans/2026-10-28-joint-evaluation-collection.md) |
| 请求级意图门（方案 B） | [正式需求规格](../specs/2026-10-27-intent-gate-b-requirements.md)、[独立资源 ADR](../adr/0002-own-ptc-gate-assets.md)、[可行性分析](../background/2026-10-27-intent-gate-b-feasibility.md)、[早期证据](../evidence/2026-10-27-intent-gate-b-feasibility.json)、[声明专用生成与同请求续步](2026-10-28-declaration-repair-engineering.md)、[ADR-0006](../adr/0006-declaration-only-repair-and-business-continuation.md) |
| PTC 与上游同步 | [需求规格](../specs/2026-10-27-upstream-sync-requirements.md)、[早期技术提案](../plans/2026-10-27-upstream-sync-plan.md)、[票据 01 本机来源检查](2026-10-27-upstream-sync-check-01.md)、[票据 02 PTC 变化检查](2026-10-27-upstream-sync-check-02.md)、[票据 03 stock read 对照](2026-10-27-upstream-sync-check-03.md)、[票据 04 引擎发布评估](2026-10-27-upstream-sync-check-04.md)、[票据 05 重复检查与审阅决定](2026-10-27-upstream-sync-check-05.md)、[票据 06 真实来源验收与交接](2026-10-27-upstream-sync-check-06.md) |
| 收口与按需维护 | [收口计划](../plans/2026-10-26-project-closeout-plan.md)、[收口记录](2026-10-26-project-closeout.md)、[报告归档](../evidence/tetris-ab/README.md) |
| PTC、read/tag/edit、窗口与 seen | [基础规格 v3](../specs/2026-10-22-ptc-hashline-requirements-spec.md)、[ADR-0001](../adr/0001-inherit-bounded-seen-guard.md)、[ADR-0002](../adr/0002-own-ptc-gate-assets.md)、[初期追溯](2026-10-23-acceptance-traceability.md)、[运行修复](2026-10-23-runtime-fix-acceptance.md) |
| cwd、MV、BOM、快照次序 | [ADR-0003](../adr/0003-effective-working-directory.md)、[0004](../adr/0004-mv-create-intent-and-snapshot-order.md)、[0005](../adr/0005-bom-preserving-hashline-read.md)、[MV 验收](2026-10-23-mv-observation-acceptance.md)、[BOM 验收](2026-10-23-bom-and-snapshot-repair-acceptance.md)、[兼容矩阵](../../tests/compat/README.md) |
| 运维 skills | [需求](../specs/2026-10-23-ptc-hashline-operations-skills.md)、[实施计划](../plans/2026-10-23-ptc-hashline-operations-skills-implementation-plan.md)、[真实宿主交付报告](2026-10-24-delivery-acceptance-report.md) |
| 默认编辑策略 | [SRS](../specs/2026-10-24-hashline-default-editing.md)、[实施计划](../plans/2026-10-24-hashline-default-editing-implementation-plan.md)、[工程切片](2026-10-24-default-edit-policy-engineering.md)、[local-01](2026-10-25-default-edit-policy-effectiveness-local-01.md)、[fix-01](2026-10-25-default-edit-policy-fix-01.md)、[完整宿主红测](2026-10-25-default-edit-policy-full-host.md)、[fix-02](2026-10-25-default-edit-policy-fix-02.md) |
| 实际生效与推广评测 | [E1～E4 验收方案](../plans/2026-10-25-default-edit-policy-effectiveness-test-plan.md)、[S0～S2 推广评测方案](../plans/2026-10-25-default-edit-policy-promotion-evaluation-plan.md)、[E3 冒烟](2026-10-25-default-edit-policy-effectiveness-e3-01.md)、[早期宿主调查](2026-10-23-host-run-deferred.md) |
| 可复现评测基础设施 | [协议补充](../specs/2026-10-25-real-model-evaluation-protocol.md)、[实施计划](../plans/2026-10-25-real-model-evaluation-implementation-plan.md)、[命令](../../scripts/evaluation/README.md)、[差距与根因、离线验收](2026-10-25-real-model-evaluation.md) |
| 逐目标、子会话与外部刺激 | [阶段计划](../plans/2026-10-25-evaluation-targets-lineage-stimuli-plan.md)、[协议补充](../specs/2026-10-25-real-model-evaluation-protocol.md)、[阶段验收](2026-10-26-evaluation-next-stage.md) |
| fork 与取消生命周期 | [验证计划](../plans/2026-10-26-evaluation-lifecycle-plan.md)、[命令](../../scripts/evaluation/README.md)、[实际宿主证据](2026-10-26-evaluation-lifecycle.md) |
| apply_patch 文件归属 | [补齐计划](../plans/2026-10-26-evaluation-apply-patch-plan.md)、[协议](../specs/2026-10-25-real-model-evaluation-protocol.md)、[解析计划取证与失败对照](2026-10-26-evaluation-apply-patch.md) |
| 首次指标的冻结范围 | [v2 计划](../plans/2026-10-26-evaluation-cohort-plan.md)、[协议](../specs/2026-10-25-real-model-evaluation-protocol.md)、[v2 验收](2026-10-26-evaluation-cohort.md) |
| 可复用候选任务集 | [计划](../plans/2026-10-26-evaluation-task-suite-plan.md)、[配置生成命令](../../scripts/evaluation/README.md)、[验收](2026-10-26-evaluation-task-suite.md) |
| 候选任务集宿主执行 | [计划](../plans/2026-10-26-evaluation-suite-host-plan.md)、[运行命令](../../scripts/evaluation/README.md)、[验收](2026-10-26-evaluation-suite-host.md) |
| 冻结设计可比性审查 | [计划](../plans/2026-10-26-evaluation-design-review-plan.md)、[审查命令](../../scripts/evaluation/README.md)、[验收](2026-10-26-evaluation-design-review.md) |
| 冻结条件判读与复用 | [判定计划](../plans/2026-10-26-evaluation-verdict-plan.md)、[命令](../../scripts/evaluation/README.md)、[判定验收](2026-10-26-evaluation-verdict.md) |
| 块定位能力限制 | [问题调查](../background/2026-10-25-hashline-block-locator-assessment.md)、[修复计划](../plans/2026-10-25-hashline-block-locator-guidance-fix.md)、[说明与诊断修复验收](2026-10-25-hashline-block-locator-fix.md) |


</details>

## 研究与外部材料

[研究目录](../background/)保留研究时点的版本、观察和建议，不覆盖现行规格；[两轮外部 A/B 报告](../evidence/tetris-ab/README.md)只作决策参考。[迁入资源清单](../evidence/2026-10-22-ptc-gate-inventory.txt)保存来源依据。

<details>
<summary>展开早期失败关系、测试入口与本地原始证据定位</summary>

## 历史失败与修复关系

| 历史记录 | 后续处置 |
|---|---|
| [local-01](2026-10-25-default-edit-policy-effectiveness-local-01.md)：Windows 加载及 read 指引 FAIL | [fix-01](2026-10-25-default-edit-policy-fix-01.md)关闭这两项；诊断用 file URL 的通过不当作原产品通过 |
| [完整宿主首轮](2026-10-25-default-edit-policy-full-host.md)：21 PASS / 1 FAIL | [fix-02](2026-10-25-default-edit-policy-fix-02.md)关闭 F-03；后续块定位轮次扩展至 33 PASS。各轮独立留证，不相加 |
| 10-23 的 1602 候选安装状态 | 1736 运行确认原 checkout 补丁解析及门禁，原始位置见下表；不代表 10-25 补丁已应用于日常宿主 |
| 10-23 的 1736 / 1807 审计 | 后续修正 scoped policy 两模式的 intent/CAS 与取证配对；v2 按 subCallId 得到 134 次完成行为调用及同轮声明，不再采用 v1 的 268 次统计，见本地 AUDIT-CLOSURE-REPORT 与[独立复核](../../.scratch/ptc-hashline/2026-10-23-1807-review-followup.md) |

1807 修正后的历史候选门禁记录：build/check exit 0、unit 44、integration 140、PTC 19、compat 21，preset/profile exit 0。后续独立复核仅运行受影响的 integration 32 与 PTC 2 项；首次 Windows 沙箱 ReplaceFileW EIO 后在获准非沙箱环境重跑通过。原始运行与后续复核不合并为一次全量结果。


## 仓库内可重跑的证明

| 行为 | 仓库内入口 |
|---|---|
| 有效工作目录 | [working-directory.spec.ts](../../packages/tool-read/tests/integration/working-directory.spec.ts) |
| MV/BOM/部分成功 | [mv-observation.spec.ts](../../packages/tool-read/tests/integration/mv-observation.spec.ts) |
| 引擎快照次序与失败 | [mv-snapshot-order.spec.ts](../../tests/compat/mv-snapshot-order.spec.ts) |
| scoped policy 两模式与 CAS | [edit-policy-composition.spec.ts](../../tests/integration/edit-policy-composition.spec.ts)、[拓扑](../../tests/integration/edit-policy-topology.spec.ts) |
| PTC 错误传播 | [edit-policy.spec.ts](../../tests/ptc/edit-policy.spec.ts)、[mv-policy.spec.ts](../../tests/ptc/mv-policy.spec.ts) |
| 日志完整性、载体与配对 | [extract-runtime-evidence.spec.ts](../../tests/integration/extract-runtime-evidence.spec.ts)、[提取器](../../scripts/extract-runtime-evidence.mjs) |
| 安装、单引擎实例、补丁与 BOM | [test-profile.mjs](../../scripts/test-profile.mjs) |
| 运维 skill 隔离与调用资格 | [operations-skills.spec.ts](../../tests/integration/operations-skills.spec.ts)（真实 preset registry/loader 装配）、[operations-context.spec.ts](../../tests/integration/operations-context.spec.ts) |
| 运维配置与运行基线 | [operations-config.spec.ts](../../tests/integration/operations-config.spec.ts)、[operations-baseline.spec.ts](../../tests/integration/operations-baseline.spec.ts)、[operations-cli.spec.ts](../../tests/integration/operations-cli.spec.ts) |
| 打包后资源可解析（PACK-01 入口切片） | [operations-pack.spec.ts](../../tests/integration/operations-pack.spec.ts) |
| 升级评估/方案/同意 | [operations-upgrade-assessment.spec.ts](../../tests/integration/operations-upgrade-assessment.spec.ts)、[operations-upgrade-proposal-consent.spec.ts](../../tests/integration/operations-upgrade-proposal-consent.spec.ts) |
| 隔离候选验证 | [operations-candidate-validation.spec.ts](../../tests/integration/operations-candidate-validation.spec.ts) |
| 目标切换与失败回退/交接 | [operations-target-switch.spec.ts](../../tests/integration/operations-target-switch.spec.ts) |
| 真实宿主交付验收（打包安装 + 真实装配 + 两条工作流） | [交付验收报告](2026-10-24-delivery-acceptance-report.md)、[入口](../../scripts/delivery-acceptance-cli.mjs)、[自检](../../tests/integration/delivery-acceptance.spec.ts) |
| 默认编辑策略的工程切片（票据 01～08） | [工程验收报告](2026-10-24-default-edit-policy-engineering.md)：各验收 ID 的证据位置、先前存在失败对照、未覆盖项 |

执行说明与环境输入见[根 README](../../README.md)及[测试说明](../../tests/integration/README.md)。用例数量是运行记录，不作为未来版本必须保持不变的常量。

## 本地原始证据的定位

以下均为 Git 忽略的本地留证路径，**不随 clone 交付**。本文只保存必要结论和可重跑入口，不复制原会话、活 profile 配置或私人绝对路径。没有这些文件时，不能宣称已经独立审阅原始日志；可依仓库测试复核对应契约，不能重造历史运行事实。

| 时间/路径（相对仓库） | 内容 |
|---|---|
| `.scratch/ptc-hashline/runtime-verification-report.md`、`runtime-fix-plan.md` | 早期目录/persona 问题与计划 |
| `.scratch/ptc-hashline/2026-10-23-relative-path-mv-rem-report.md` | MV 原始实测失败 |
| `.scratch/ptc-hashline/evidence/phase-a-red.txt` | 早期修复前红测 |
| `.scratch/ptc-hashline/evidence/20261023-1453/` | BOM 丢失与快照文案原始失败 |
| `.scratch/ptc-hashline/evidence/20261023-1602/` | 红绿测试、BOM 矩阵及候选门禁；候选安装树已清理 |
| `.scratch/ptc-hashline/evidence/20261023-1736-a4d1/` | 原 checkout 整合、实际会话与字节证据；部分解释已被后续审计纠正 |
| `.scratch/ptc-hashline/evidence/20261023-1807-4b1d/` | AUDIT-CLOSURE-REPORT、v1/v2 取证、修正前后门禁 |
| `.scratch/ptc-hashline/2026-10-23-1807-review-followup.md` | 五项修正后的独立复核 |

原始报告保持原样；有条件保存关键原始证据时，应另行脱敏并正式归档，而不是批量追踪整个 `.scratch`。本索引不能替代原始运行日志。

## 仍保留的范围限制

- 早期 scoped policy 夹具仍只证明其范围；后续完整 preset/进程 PTC/子代理路径按 fix-02 与块定位报告独立计证。
- 完整宿主使用固定适配器，真实模型请求为零；官方进程 PTC 的 sandbox enforcement 为 partial，不证明完整沙箱隔离。
- 真实 sandbox 后端、多 provider、replace/patch/apply_patch 的 BOM 保真未做系统验收。
- MV 源删除无版本条件、多节无全局事务，属于已知边界；seen 是有限守卫，不是权限边界。
- 剩余 E2 包括无 session/SDK、多窗口上限、remount 失效、真实后端 retry 竞争/取消/unknown、MV+内容混合及更多字节/载荷组合，详见 fix-02 的剩余验收。
- 已有 E3 冒烟但未整体通过，E4 正式对照未执行；`.tmp/order-config-migration/` 另有本地演练记录，本轮仅确认材料存在，未独立重验，不并入正式验收计数。

</details>
