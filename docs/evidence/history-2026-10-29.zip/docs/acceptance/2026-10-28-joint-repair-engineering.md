# 意图门 × 工具路径联合修复：工程验收（2026-10-28）

日期：2026-10-28
范围：按[联合执行入口](../../.scratch/intent-gate/execute-repair-plans-prompt.md)推进两份计划——[意图门修复实施计划](../plans/2026-10-28-intent-gate-repair-implementation-plan.md)（P0–P6）与[工具路径修复计划](../plans/2026-10-28-ptc-hashline-tool-routing-repair-plan.md)（T0–T4）。
授权范围：源码/文档/测试修改与隔离候选环境中的工程验收；**不含**真实模型或付费调用、不含安装/重启日常宿主、发布或目标切换、不含修改 DSH 本体。

本文件是这次联合修复的**单一运行记录**（第 1～14 轮持续追加），每节注明它来自哪一轮或哪几轮。逐条结论都指回命令、退出码、源码锚点或产物路径；未执行的项目显式记为 GAP/BLOCKED，不用相邻层 PASS 代替。第 10 轮起另有一份[套件分诊](../../.scratch/intent-gate/evidence/2026-10-28-joint-repair/suite-triage.md)说明「本机能跑哪些 spec、为什么」，它不是产品判定。

## 1. 结论先写清

- **工程范围通过（受限）**：P0 的规格/ADR/接口取证完成；P1+T1 的 persona 协调修改与实际 assembly 契约检查通过；P2 的等待与答案关联缺陷已修并有红转绿证据；**P4 的等待上限、取消与三段记账在 seam 级落地**（第二轮）；**T2 的按任务目标判读已实现**（fixture 正反例 + artifact/CLI + 提取器接线 + 稳定原因码）；**P3 已由用户选定路线 1，呈现规则核心实现并有 7 条用例**（浏览器半仍缺依赖与构建）；T0 的 SDK 可见性由只读探针证到 read 路径，**edit 写路径被宿主沙箱 ACL 拒绝（环境）**。
- **产品语义与工具采用效果仍为 GAP**：真实模型一次也没有运行；[联合验收清单](../plans/2026-10-28-joint-real-model-evaluation-manifest.md)已冻结候选案例与预算 manifest，等待用户填参数与授权。
- **两项 BLOCKED**：P3（请求层呈现「恢复中」）——官方接口复核后只剩「伪造空 assistant/message」或「加 Client 面呈现插件并做真实 UI 穿透」两条路，后者在本环境不可验证；P5/T3 的完整宿主/交付门禁——本机沙箱拒绝嵌套进程（`spawn EPERM`）与文件安全调用（`SetFileSecurityW EACCES`），vitest 与 `test:host-gate`/`test:delivery` 无法启动。
- 因此仍**不能**宣布联合需求完成：需补充 P3 的呈现路线、P4 的压缩与真实取消矩阵、P5/T3 的整宿主门禁、T2 在真实轨迹上的复核，以及 P6/T4 的真实模型执行。

## 2. P0：基线、契约与接口

### 2.1 基线身份（实施前，工作树干净）

| 项 | 值 |
|---|---|
| 仓库 HEAD | `0daf35d`（`git status --porcelain` 为空） |
| 宿主 checkout | `deepseek-harness` 0.2.1-rc.2 @ `687f282e8625c6b8d11ff58211a90524be2e4317`，工作树干净，仅只读 |
| Node / pnpm | v24.19.0 / 11.28.5 |
| hashline 锚点 | `@hy-sde-org/dsh-hashline@0.2.1-alpha.4`，realpath 落在本仓库 `node_modules`，package.json sha256 `d7046e84…` |
| tool-edit 锚点 | `@hy-sde-org/dsh-tool-edit@0.2.1-alpha.4`，sha256 `32e87e7f…` |
| 契约包 | `@deepseek-ai/dsh-tools@0.2.1-rc.2` `13adfd07…`、`dsh-fs@0.2.1-rc.2` `fa6fe827…`、`dsh-agent-loop-testkit@0.2.1-rc.2` `748c38bc…` |
| preset 资产（实施前） | `intent-gate-watchdog.mjs` `685f8eda…`、`personas/orchestrator.md` `29c0d73d…`（LF 归一化） |
| preset 资产（实施后） | watchdog `0b000e17…`、persona `ecb636a8…`（`check:preset` 已同步钉住；完整摘要见 `scripts/check-preset.mjs` 的 `EXPECTED_DIGESTS`） |
| pnpm-lock | sha256 `9423e712…` |

基线与探针原始输出：`.scratch/intent-gate/evidence/2026-10-28-joint-repair/`（含基线快照 `.tmp/baseline.json`——已被忽略，故关键值抄进 §2.1——以及 runner、探针脚本与全部 `run-*.log`）。

### 2.2 契约修订（先改规格，再改实现）

[规格](../specs/2026-10-27-intent-gate-b-requirements.md) 本轮修订：IG-B-03（歧义是正常交互，不是输入错误）、IG-B-05（请求层不把失配当结论，最多看到「正在补全意图声明」）、IG-B-06（取消后排队中的修复与续步零执行）、IG-B-07（提问也是插件可判读的正式路径）、IG-B-14（待答状态按问题身份+所属请求保存）、IG-B-16（只有该问题自己的答案或宿主结算能结束等待；取消不是选择；不保留永久锁）、IG-B-17（续步后仍有未解歧义则先澄清）、IG-B-18（问题阶段不计修复、不另给预算）、新增 **IG-B-19**（提问与业务动作分开）、新增 **IG-B-20**（请求层呈现分档），并新增验收 IGB-AC-16/17/18。

[ADR-0006](../adr/0006-declaration-only-repair-and-business-continuation.md) 新增「修订 2026-10-28」：原「terminal 后 followup」代价经 P0 复核**仍然存在**，并给出路线 A/B/C 的判定与缺口；澄清等待改为按问题身份与所属请求判定；提问与业务动作分开。

### 2.3 问题服务与答案关联的真实形状（只读源码证据）

| 需要的能力 | 真实接口 | 锚点（宿主 checkout） |
|---|---|---|
| 提问工具与阻塞语义 | `ask_user_question`（`mode: 'legacy'` 阻塞式，`execute` 等 `ctx.userQuestions.ask()` 返回答案批） | `packages/interaction/tool-ask-user/src/index.ts`（tool definition 与 `execute`） |
| 答案批形状 | `{ answers: [{ id, selected: string[], custom? }] }` | 同上（output schema） |
| 外层调用的结算 | `tool/result` 事件**不带工具名**，答案在 `data.message.toolCallId` 与 `data.message.content` | `packages/core/session/src/types.ts:352-386`、`packages/llm/llm/src/message.ts:172-180` |
| PTC 内层调用的结算 | `tool/ptc-dispatch-start` / `tool/ptc-dispatch`，含 `rootCallId/parentCallId/subCallId/name/content` | `packages/core/tools/src/types.ts:11-62` |
| 迟到答案（timed 模式） | `user-question-reply` 消息，`source: { kind, callId, outcome: 'answered' }`，正文为 `answer_to_pending_question` JSON | `packages/interaction/user-questions/src/types.ts`（MessageSourceMap 增强）、`src/index.ts`（`answer()`） |
| 取消/拒答 | 工具调用以 `ASK_ABORTED` 等错误结算（`isError`） | `packages/interaction/user-questions/src/index.ts`（`abortedQuestion`） |

由此得到本轮的**实现缺陷依据**：旧实现按 `data.name === 'ask_user_question'` 判 `tool/result`，而该事件根本没有 `name` 字段 —— 阻塞式提问的答案**从未**结算过等待，等待只被「任何真实用户输入」的 pre-step 无条件清空。这正是计划 §2 表格里的「非答案可清除待答」。

### 2.4 恢复路线复核（P3 的前置）

见 [ADR-0006 修订 §1](../adr/0006-declaration-only-repair-and-business-continuation.md) 的表：路线 A（同 turn 换新 step）在 `agent.ts:506-550` 上被证否——非 error 结束必然 append `assistant/message`（含空正文），error/aborted 才是 `assistant/attempt` 且只能走 `retry`（同一步、同一 assembly）。路线 B 的「恢复中」文案在 Client 平面（`packages/client/ui-chat/src/client/locale.ts` 的 `message.turnError`），需要 Client 面插件与真实 UI 穿透，本轮既无资产也无环境。故 P3 记 **BLOCKED**，缺口具体到「一个 Client 面恢复状态插件 + 浏览器穿透证据」。

## 3. P1 + T1：persona 协调修改（实现 + 实际 assembly 契约检查）

修改 `presets/ptc-hashline/personas/orchestrator.md`：

- **三选一决策**写进 Phase 0：明确则推进 / 有依据的多解则列工作差异并问 / 缺一项必需事实则先自查再问；并明确「这是正常交互，不是坏输入、不是拒绝、永远不是 error 消息」。
- **歧义规则，不内嵌案例**（2026-10-28 用户要求按 KISS/奥卡姆剃刀清理该文件后）：Phase 0 只写规则——列出两条解读、说出它们的工作差异、问哪条；不复述输入已给的事实；不硬凑提问；输入已答或用户要双路径时直接按条件交付。原先粘进 persona 的支付场景属于**评测案例**，保留在[计划 §3](../plans/2026-10-28-intent-gate-repair-implementation-plan.md) 与[冻结清单 §6](../plans/2026-10-28-joint-real-model-evaluation-manifest.md)，不再进入每次生成的提示词；persona 现在**全英文、零中日韩字符**（契约用例断言）。
- **提问专用程序**：`run_code` 里只调 `tools.ask_user_question`，返回后不得在同一程序继续；答案属于下一次生成。
- **等待语义**：只有该问题自己的答案能结束等待；裸「继续」、插件通知、别的工具结算、别的问题的答案都不解锁；独立请求可推进且旧问题仍在。
- **工具路径（T1）**：按任务的路径清单，参数全部取自 SDK 与实际返回值——`tools.read({ file_path })` 的 `lines/tag/totalLines/nextAction`、`tools.edit({ input: '[path#tag]\nPUT 10.=10:\n+text' })`、`tools.write({ file_path, content })` 仅用于新建、`tools.glob/grep`、平台 shell（`tools.pwsh`）、数据计算留在 `run_code`；失败要读错误、不得静默旁路。
- **两处冲突消解**：「no status updates」明确不再压制 `Intent:` 行与澄清/等待/恢复状态；声明专用修复与业务续步的既有契约保留。

契约检查（实际 assembly，非只读源码）：新增 `tests/integration/persona-intent-gate-contract.spec.ts` 5 条，全部 PASS（`run-persona-contract-final.log`）。

## 4. P2：等待、答案关联与提问边界（红转绿）

### 4.1 先暴露缺陷，再修

新增/改写的检查先按旧实现跑出 FAIL：`keeps the wait open …`（旧 `settle` helper 用 `tool/ptc-dispatch` 结算一个外层 `tool/call` 问题，旧实现「按名字结算」能过、新实现按身份结算不过——这正是缺陷面）；改写为身份匹配后转绿。另新增 4 条红转绿用例：裸「继续」后仍拒绝动作（FIX-05）、错 callId / 陈旧答案不解锁、问题自己的 `tool/result` 解锁、独立请求可推进且旧问题仍可被自己的答案结算。

### 4.2 实现要点（`presets/ptc-hashline/intent-gate-watchdog.mjs`）

- 派生状态由「会话级布尔值」改为 `{ request, openQuestions[], answeredInProgram[] }`：每个实质用户输入开一个新请求；裸致谢/裸继续沿用当前请求。
- 结算只认同身份：`tool/result` 的 `message.toolCallId`、`tool/ptc-dispatch` 的 `subCallId`、`user-question-reply` 的 `source.callId`；错 id、陈旧结果、别的问题的结算都不解锁。
- pre-step **不再**清空等待（这是原缺陷的直接产生点）；宿主答案消息一律要求声明（选项标签叫「继续」也按答案处理）。
- 新增 `tools/pre-execute` 守卫：问题在自己的 `run_code` 根调用里结算后，同根调用的后续业务派发被拒（IG-B-19）。
- 旧记录兼容：只有 `awaitingAnswer` 布尔值的记录仍按「仍在等待」读取（`awaitingAnswer()` 的 fallback 分支，有单测）。

### 4.3 未覆盖（GAP，明确留待下一轮）

- 「等待中忽略其他工具的结算」在 P2 用例里用合成事件证明；**真实宿主**（打包安装 + 真实 launcher + 真实问题面板）的等价证据仍缺 —— 属 P5/T3 门禁，本轮环境 BLOCKED。
- 用户「明确取消原目标」目前只能由问题自身的错误结算（`ASK_ABORTED`）体现；「同一请求可推进但不保留永久锁」在真实面板关闭路径上未验证。

## 5. P4：预算、取消、资源上限与三段成本（第二轮，seam 级 PASS；真实矩阵 GAP）

### 5.1 本轮实现

1. **等待上限真的会咬住**（IG-B-15 修订后）：`llm/stream` 的暂存不再只在「有 chunk 到达时」检查时间。实现用一个与来源竞争的 deadline（`setTimeout` + `Promise.race`），命中即以 `INTENT_DECLARATION_LIMIT` 停止；被停下的来源**不被抽取**而是释放（`source.return()`，且**不 await** —— 停在自身 await 里的生成器可能永不结算，门不能挂在已停的流上），已收到的字节丢弃、不发布，只把 provider 已报的 `usage` 转出去（成本仍可见）。上限判定被移到 `assembleAttempt` 之前，因此**没有 finish 的停滞尝试**同样被停（这正是 finish-time 检查抓不到的情形）。
2. **取消贯穿四个断点**（第 2 轮落地 1/2/3，第 9 轮补 3 的真实重启变体，第 4 轮补 4）：`turn/end.reason.kind === 'aborted'` 时清除声明阶段与待修复记录（断点 1：已判定未排队）；`agent/turn-stopping` 在 `signal.aborted` 时不再投递续步（断点 3：声明已提交未调度）；声明专用步骤自身被取消时其真实终态原样重放、不续步、不二次修复（断点 2）。
3. **三段成本分别可对账**：被扣下的尝试保留 usage 块、正文为空；声明阶段没有 usage 时保持 unknown（不伪造 0）；续步阶段不写第二条预算通知（整条请求只写 1 条修复通知）。

### 5.2 新证据（`tests/integration/intent-gate-request-scope.spec.ts`，本节 5 条；与 §5.4 的 3 条合计 8 条）

| 用例 | 断言 |
|---|---|
| 停滞适配器在上限处停止 | 停在 `INTENT_DECLARATION_LIMIT`；零发布、零 `assistant/message`；来源 `return()` 被调用 1 次；`request-error` 不复用预算、`agent/status` 不打开修复；该请求随后仍能用掉它唯一一次修复 |
| 取消后不打开排队中的声明修复 | `followups` 为 0，重复 idle 也不打开 |
| 已中止的 turn 不投递业务续步 | `injected` 与 `inbox.nextStep` 均为 0 |
| 声明步骤生成中被取消 | 真实 aborted 终态原样重放；零 `assistant/message`；只开过 1 次修复；`injected` 为 0 |
| 三段成本 | 被拒尝试带 usage 且正文为空；声明阶段无 usage 时保持无（unknown）；日志里整条请求只有 1 条以 `was withheld` 开头的插件通知 |

### 5.3 三段成本有了可复核的账本（第二轮补齐）

`requestAccounting(events)` / `summarizeAccounting(accounting)` 加在同一个门模块里，**从同一份正式会话日志**重建每一条请求的账本，不另立私有事实源：按 `first` / `declaration` / `business` 三个阶段分别记 attempts、published、input/output tokens 与 **usageUnknown**（适配器没报就记 unknown，绝不补 0）；同时记每条请求用掉的修复数、问过的问题及其是否被自己的答案结算、每个 turn 的终局。分段依据是可判读的正式事实：修复通知前缀 → declaration、续步通知前缀 → business、实质用户输入 → 新请求（裸「继续」不开口子）。

证据：同名单元测试 5 条（`tests/unit/intent-gate-declaration.spec.ts` 的「per-request accounting from the formal log」段），含「unknown 不变成零」「裸继续不新开请求」「问题的结算归属」「摘要不含正文」与「从同一批事件重建后总量不变（重载不重置预算）」。

### 5.4 断点 4 与「重载不重置」的跨层证据（第四轮）

| 用例 | 断言 |
|---|---|
| 取消发生在业务步（断点 4） | 声明已发布、续步已排队；用户在该步取消后，`agent/status` 不再打开任何 follow-up，`agent/turn-stopping` 在 aborted 信号下不再投递第二条续步（`injected` 计数不增） |
| 账本在「重载」后仍然一致 | 用同一条请求的会话事件构建账本两次（第二次走 JSON 往返，等价于重新读日志），`totals` 完全相同、`repairs` 仍为 1、声明阶段 `published` 仍为 1 —— 预算与阶段不因重读而重置 |
| 断点 3 的真实重启（第 9 轮） | 用**新挂载的门实例**叠同一份日志（同进程换 agent 对象不算重启）：崩溃窗口里没有续步排队；重启后不打开新 follow-up、不投递幽灵续步；账本仍 `repairs=1`、声明 `published=1`；日志里只有 1 条修复通知（不会凭空多出第二次修复） |

四个断点至此都有本层证据：1（已判定未排队）、2（声明生成中）、3（声明已提交未调度）、4（业务执行中，gate 侧不再排队）。真实取消矩阵（真实进程、真实压缩）仍需整宿主。

### 5.5 仍为 GAP

- 断点 4（业务执行中）的取消属于循环自己的语义，本层只证明门不再排队任何东西；真实取消矩阵需整宿主（P5/T3）。
- 压缩（compaction）重放后的等待/预算/最新约束未在本层验证；真实 `agents.resume` + 压缩路径仍需宿主。
- ~~usage 的分段账本尚未落成产物~~ —— 已在 §5.3 与证据提取器的 `accounting` 块落地（逐请求三阶段 + `usageUnknown`），但「跨进程 resume 后的账本一致性」仍待真实恢复验证。

## 6. T2：按任务目标判读的可复核证据（判读 + artifact/CLI + 提取器接线 + 稳定原因码；真实轨迹 GAP）

新增 `scripts/tool-usage-judgement.mjs`（+ `scripts/tool-usage-judgement.d.mts`），复用现有解码器产出的同一种记录（`{ type, seq, time, data }`，见 `presets/ptc-hashline/operations/session-log.mjs`），只补计划说的「当前缺失的判读」：

- **同一 subCallId 的 start/settle 配成一次调用**；只有 start 的记 `start-without-settle` 并落 `unknown`，只有 settle 的记 `settle-without-start`，都不当成「调用悄悄消失」。
- **按「任务目标 + 目标文件」判读**：任务类型（text-read / text-update / create / search / shell / no-file-work）各有一条适用路径；同一工具在不同任务里含义不同——`write` 对 create 是正路，对既有文件更新是 proven bypass。
- **四种结论分开**：工具采用（配对调用计数）、路径（目标文件是否真的走 read→edit）、proven bypass（触及目标的 shell / 既有文件的 `write`）、candidate（程序正文里出现 `node:fs`/`child_process` 等静态信号）。**candidate 永不等于证明**，但只要它提及目标文件，该任务就拿不到「applied-tool-path」的干净结论（记 `unknown`）——这正对应计划里「先工具读再 fs 写也要判不合格」与「证据缺失不能记零旁路」。
- **原因码是稳定枚举**：`UNKNOWN_REASON`（12 个，如 `unsettled-dispatch`、`unexplained-native-candidate-touching-target`）与 `EVIDENCE_GAP`（5 个，如 `settle-without-start`），全部在 `REASON_DICTIONARY` 里有一行中文释义；单测同时验证「声明的码都有释义」与「任何输入下只会产出已声明的码」，因此跨轮、跨候选可以直接比码而不是比措辞。
- 业务正确性不由该模块声称：它只输出路径与旁路证据，文件对错仍由独立检查。

第二轮又补上「在真实文件上跑」的入口：

- `judgeSessionArtifact({ sourcePath, tasks })` 用**已交付的解码器**（`presets/ptc-hashline/operations/session-log.mjs` 的 `decodeArtifact`/`parseRecords`；支持 zstd 帧与裸 JSONL v4）读取整份会话并逐任务判读；**撕裂帧或坏行会让结果 `complete: false`，并把任何乾淨结论降为 `unknown`**（追加 `session-artifact-incomplete`），因为带洞的日志不能支撑「没有旁路」的断言。
- CLI：`node scripts/tool-usage-judgement.mjs --source <会话文件> --tasks <manifest.json> [--out <file>]`，只输出 `source/format/frames/records/torn/failures` 与逐任务一行摘要（不含参数、正文或程序源码）；不完整时退出码 2。
- 实跑证据（本机、只读）：`cli-demo-session.jsonl` + `cli-demo-tasks.json` → exit 0，输出
  `T3-update text-update bypass read=1 edit=1 write=1 shell=0 provenBypass=1 …`（同一既有文件先 read→edit 再被 `write` 覆盖 → proven bypass）与
  `T8-no-file no-file-work no-file-work …`（无文件任务不因零文件工具被误判）。

证据：`tests/unit/tool-usage-judgement.spec.ts` 14 条 + `tests/integration/tool-usage-judgement-session.spec.ts` 3 条全 PASS（含「坏行不得升级为乾淨结论」）。第四轮把判读接进既有的证据提取器，使**一次运行同时给出三份可核对的结论**（「回复是否在动手前声明」「任务的真实目标是否走了适用路径」「这条请求三个阶段各花了多少」）；第五轮补齐了成本账本块（「回复是否在动手前声明」与「任务的真实目标是否走了适用路径」）：`scripts/extract-runtime-evidence.mjs` 新增可选 `--tasks <manifest.json>`，报告里增加 `toolPath` 块（`incomplete`、逐任务 `verdict/readTargets/editTargets/writeTargets/shellTargets`、`provenBypass`、`candidates`、`gaps`、`unknowns` 与一行摘要）。三条约束写进代码：**不给 `--tasks` 时 `toolPath` 为 `null`（旧报告逐字兼容）**；`toolPath` 只保留 id 与计数，不含参数、正文或程序源码；**会话证据不完整时任何乾淨结论降为 `unknown`**。第五轮又加了**总在场的 `accounting` 块**：同一区间、由门模块自己的 `requestAccounting` 生成（`totals` + 逐请求三阶段 attempts/published/tokens/usageUnknown、修复数、问题与结算、turn 终局），于是"声明 / 路径 / 成本"三问出自同一份证据，unknown 仍是 unknown。

证据：`tests/integration/extract-runtime-evidence-tool-path.spec.ts` 5 条 PASS（3 条判读接线 + 2 条账本；含「序列化后的 `toolPath` 不含 file_path/PUT/程序源码」的泄漏检查）。

真实轨迹复核（TOOL-01/02/03/08 的运行证据）仍为 GAP：本机无法产生真实会话轨迹（§8）；既有 `tests/integration/extract-runtime-evidence.spec.ts` 走子进程 CLI，在本沙箱同样无法执行（18 条因 `spawn EPERM` 失败，属环境）。

## 7. 验证命令、退出码与覆盖

> 运行环境说明（重要）：本机沙箱拒绝任何嵌套进程（`spawn EPERM`）与 `SetFileSecurityW`（`EACCES`）。因此 `vitest`（vite 用 esbuild 子进程加载配置）与所有需要打包安装/真实 launcher 的门禁无法启动（证据：`run-vitest-blocked.log`）。为仍有真实回归证据，本轮用 `.scratch/intent-gate/evidence/2026-10-28-joint-repair/` 下的最小 runner（`register.mjs` + `vitest-shim.mjs`）**原样执行仓库里的 spec 文件**：被测源码、断言与 spec 都是仓库原件，只有 runner 换成了纯 node。该 runner 的已知限制：只实现断言子集与按 suite 作用域的 hooks，不实现 `vi.useFakeTimers`/`mock` 等特性，因此**只对下列四个 spec 给出验收级结果**，其他套件在其下的结果不作证据。

| 命令 | 退出码 | 覆盖 |
|---|---|---|
| `node --import ./.scratch/…/register.mjs tests/unit/intent-gate-declaration.spec.ts` | 0 | 43 tests（34 原有 + 4 条问题身份 + 5 条请求账本） |
| `node --import ./.scratch/…/register.mjs tests/unit/tool-usage-judgement.spec.ts` | 0 | 16 tests（T2 判读：配对、各任务路径、proven bypass 与 candidate、unknown 语义、稳定原因码字典与可达性） |
| `node --import ./.scratch/…/register.mjs tests/integration/intent-gate-request-scope.spec.ts` | 0 | 52 tests（等待/答案关联 9 条 + P4 上限/取消/重启 8 条 + 既有 35 条） |
| `node --import ./.scratch/…/register.mjs tests/integration/persona-intent-gate-contract.spec.ts` | 0 | 5 tests（本轮新增；实际 assembly） |
| `node --import ./.scratch/…/register.mjs tests/integration/persona-scope-contract.spec.ts` | 0 | 3 tests（persona 未被 shadow 回归） |
| `node --import ./.scratch/…/register.mjs tests/integration/tool-usage-judgement-session.spec.ts` | 0 | 3 tests（artifact 读取、坏行降级、manifest 形状） |
| `node --import ./.scratch/…/register.mjs tests/integration/extract-runtime-evidence-tool-path.spec.ts` | 0 | 5 tests（`toolPath: null` 兼容、判读块无泄漏、不完整会话降级、账本 unknown 保留、三阶段分离） |
| `node scripts/tool-usage-judgement.mjs --source … --tasks … --out …` | 0 | CLI 实跑：逐任务一行摘要，无参数/正文泄漏（样例见 §6） |
| `node scripts/evaluation/joint-plan.mjs --cases docs/plans/2026-10-28-joint-real-model-cases.json --out …` | 2（未授权，预期） | 冻结案例自洽（20/12+8/40/240）、11 个必填项待填、列出 40 条会话；**零调用** |
| `node scripts/evaluation/joint-plan.mjs --cases … --runs scripts/evaluation/joint-runs.example.json --out …` | 0 | 对账形状：2 行 + 38 个 `session-did-not-run` GAP（示例输入，非测量结果） |
| `node scripts/evaluation/joint-rehearsal.mjs --root …` | 0 | **流水线演练**（固定夹具，非模型）：artifact → 提取器报告 → runs.json → 对账，2 行 / 38 GAP / T3 判 `applied-tool-path` / G1 一次修复且成本保留 |
| `node scripts/suite-triage.mjs --from <triage.log> --out <dir>` | 0 | 重新生成套件分诊（23 绿 / 11 runner 缺特性 / 21 沙箱拒绝 / 2 CLI 子进程无输出） |
| `node --import … register.mjs tests/unit/suite-triage.spec.ts` | 0 | 3 tests（四类原因不可混淆、日志解析、产物含「不是产品判定」声明） |
| `node --import … register.mjs tests/unit/candidate-evidence.spec.ts` | 0 | 6 tests（候选表：一条候选才可 PASS、跨 gate 摘要冲突 FAIL、缺 gate BLOCKED、blocked id 记 GAP、无摘要记为无法命名候选） |
| `node --import … register.mjs tests/unit/intent-recovering-presentation.spec.ts` | 0 | 7 tests（P3 规则核心：只升级两个声明码、拒绝每一种不该升级的结局、只认本产物通知、拒绝陈旧/跨 turn 升级、文案无失败词、前缀与码表与门一致） |
| `node --import … register.mjs tests/integration/extract-runtime-evidence-presentation.spec.ts` | 0 | 4 tests（无浏览器时的 P3 证据：真实 artifact 上每 turn 应呈现为什么、拒绝升级的结构原因、所有策略停摆都列出而不是省略、provider 失败/取消/普通 turn 不置评） |
| `node scripts/candidate-evidence.mjs --host … --surface … --delivery docs/acceptance/2026-10-28-delivery-acceptance-summary.json` | 2（GAP，预期） | 候选表实跑：identity PASS／host PASS／surface PASS（browser 未验）／delivery **GAP**（21 PASS / 9 BLOCKED id）→ 总判 **GAP**，不升级为 PASS |
| `node --import … register.mjs tests/unit/host-gate-evidence.spec.ts` | 0 | 7 tests（宿主证据预检：字段/身份摘要/固定适配器/case 覆盖与失败） |
| `node scripts/host-gate-evidence.mjs --evidence … --require …` | 0 / 2 / 2 | CLI 冒烟（**合成样例**，非宿主运行）：合规样例 0；资产摘要不符 2；缺必需 case 2 |
| `node scripts/host-gate-evidence.mjs --kind surface --evidence …` | 0 / 2 | 呈现端预检（**合成样例**）：合规样例 0 且固定列出 `browser-not-verified` GAP；泄漏样例 2（S3 有可见正文、S1 日志非零） |
| `node scripts/check-preset.mjs` | 0 | 行内上限 = 模块默认值、资产摘要（已按本轮改动更新）、preset 形状 |
| `node node_modules/typescript/bin/tsc -p tsconfig.tests.json` | 0 | 测试与脚本的类型检查（`check:tests` 的等价命令） |
| `node --import … t0-read-probe.mjs` | 0 | T0：`run_code` 内经 PTC 调用 `tools.read` 成功（tag `F74C`、`tagged: true`、`nextAction: null`）；`tools.edit` 在写盘阶段失败（见 §8） |
| `node --import … policy-probe.mjs` | 0 | 复现 `edit` 写路径的 `SetFileSecurityW EACCES`（环境）|
| `npx vitest run --config vitest.unit.config.ts …` | 1 | **BLOCKED**：`errno -4048 / code 'EPERM' / syscall 'spawn'`（vitest 无法加载配置） |
| `pnpm check` / `pnpm test:unit` / `test:integration` / `test:ptc` / `test:compat` | 未运行 | BLOCKED（同上；`pnpm build` 需要子进程） |
| `pnpm test:host-gate` / `test:surface-gate` / `test:delivery` / `test:profile` | 未运行 | BLOCKED（`installBundle` 需要 `pnpm pack`/`npm install` 子进程；沙箱拒绝） |

**claims ↔ evidence 复核（第 15 轮起，第 20 轮随 P3 提取器用例更新）**：把 14 个 spec 的 `it(` 注册数与最近一次运行日志的通过数逐一对齐——43 / 7 / 16 / 7 / 12 / 3 / 6 / 52 / 5 / 3 / 4 / 5 / 4 / 2，**合计 169，0 失败，零不匹配**；本文件引用的 34 个产物/源码路径也逐个解析：仓库内路径全部存在，宿主 checkout 路径由 §2.3 表头标注，用户待填模板（`approval.json`）已写明来源。核对记录：`.scratch/intent-gate/evidence/2026-10-28-joint-repair/claims-audit.txt`。

## 8. 环境阻塞（带证据，不冒充通过）

| 阻塞 | 证据 | 影响 | 分类 |
|---|---|---|---|
| 嵌套进程一律 `EPERM` | `node -e "execFileSync(process.execPath, …)"` → `spawnSync … EPERM`；`npx vitest` → `EPERM spawn` | vitest/整宿主/交付门禁无法运行 | BLOCKED（环境） |
| edit 写路径 `SetFileSecurityW EACCES` | `run-t0-read-edit-probe.log`、`run-policy-write-probe.log`；工作区内的 temp 目录同样失败 | T0「实际执行一次 edit」「默认编辑策略回归」无法在本环境取证 | BLOCKED（环境） |
| 真实 UI/浏览器 | 无浏览器驱动；日常宿主不允许重启 | P3/FIX-08/IGB-AC-18 的真实呈现端证据 | BLOCKED（环境+缺资产） |

**套件分诊（第十轮起，第十一轮固化为可复跑脚本 `scripts/suite-triage.mjs`，供下一次有权限环境对照）**：用本地 runner 把 `tests/unit` + `tests/integration` 全部 57 个 spec 逐个跑了一遍（`.scratch/intent-gate/evidence/2026-10-28-joint-repair/suite-triage.{json,md}`）：**23 个跑绿**；其余按原因分类——**11 个 runner 缺 vitest 特性**（`expect(...).resolves/rejects` 之外的高级用法、`vi.mock`、fake timers 等）、**21 个沙箱拒绝**（14 个直接 `EPERM`/`EACCES` + 7 个 edit 写路径 ACL）、**2 个 CLI 子进程产出为空**。这份分诊**不是产品判定**：它只说明「本机能跑到哪、为什么跑不到」，真实数字必须由整宿主门禁重新取证。

## 9. 逐项状态（P0–P6 / T0–T4）

| 工作包 | 状态 | 依据 / 缺口 |
|---|---|---|
| P0 基线与接口 | **PASS（受限）** | §2；恢复路线判定见 ADR 修订；缺真实宿主的问题事件样本（BLOCKED） |
| P1 persona 协调 | **PASS（工程）** | §3 + 5 条 assembly 契约用例；语义效果属 P6 |
| P2 等待与答案关联 | **PASS（seam 级）** | §4：红转绿 9 条 + 4 条单测；真实面板路径 GAP |
| P3 无粗暴失败的格式恢复 | **部分实现（用户已选路线 1）/ 浏览器接线 BLOCKED** | 用户 2026-10-28 选定路线 1。**已做**：接缝复核证明不需改宿主（节点定义可"认领"事件：`assembler.ts:519-550`；渲染器是公开 slot：`register-node-renderers.ts`；同 kind 不可重复注册：`definition-registry.ts`）+ 规则核心 `presets/ptc-hashline/client/presentation.mjs` + 7 条用例。**已做（浏览器无关的那半）**：证据提取器新增 `presentation` 块——用真实会话 artifact 算出每个策略 turn 应呈现为「恢复中」还是失败，并给出拒绝升级的结构原因（`tests/integration/extract-runtime-evidence-presentation.spec.ts` 4 条）。**未做**：浏览器半需宿主 client 包与 tsdown 构建，本环境 `pnpm install`/`SetFileSecurityW` 均被拒；故意不建 `packages/*` 空壳以免拖垮 `pnpm build`/`test:delivery`。详见[设计稿 §3b/§7](../plans/2026-10-28-p3-route1-client-presentation-design.md) |
| P4 预算/取消/恢复/成本 | **PASS（seam）/ GAP（真实矩阵）** | §5：上限在生成未结束时生效并释放来源、**四个断点**的 gate 侧断言（含断点 3 的**真实重启**模拟：新挂载 + 同一日志）、三段成本**账本**（unknown 保留，重读不重置）；真实取消矩阵与压缩仍需宿主 |
| P5 完整宿主与交付验收 | **BLOCKED** | §7/§8：`test:host-gate`/`test:surface-gate`/`test:delivery` 无法启动；已写[整宿主运行手册](../plans/2026-10-28-joint-host-acceptance-runbook.md)（命令、映射、判定规则），交付两层证据预检 `scripts/host-gate-evidence.mjs`（12 条用例）与**候选表** `scripts/candidate-evidence.mjs`（identity/host/surface/delivery 四轴合成一个判定，6 条用例）——两者都不是门禁运行 |
| P6 真实模型效果 | **GAP（已准备 + 流水线演练）** | §10：[联合清单](../plans/2026-10-28-joint-real-model-evaluation-manifest.md) + [机器可读案例](../plans/2026-10-28-joint-real-model-cases.json) + `joint-plan`（7 条用例）+ `joint-rehearsal`（2 条用例：固定夹具跑通采集→报告→对账）+ [采集操作单](../plans/2026-10-28-joint-evaluation-collection.md)；未执行任何模型调用 |
| T0 SDK 可用性 | **PASS（read 路径）/ BLOCKED（edit 写路径）** | §7 探针；未做打包安装 |
| T1 persona 工具路径 | **PASS（工程）** | §3；模型是否采用属 T4 |
| T2 按任务目标判读证据 | **PASS（判读 + artifact/CLI + 提取器接线 + 稳定原因码）/ GAP（真实轨迹）** | §6：模块 + 16 条用例（含原因码字典与可达性）+ 4 条 artifact 用例 + 5 条提取器接线/账本用例 + CLI 实跑；真实会话轨迹仍无法在本机取得 |
| T3 固定适配器整宿主验收 | **BLOCKED** | 同 P5 |
| T4 真实模型采用 | **GAP（已准备）** | §10：8 类工具任务已冻结并带 `kind/targets`，对账走 `toolPath` 判读；未执行 |

## 10. P6/T4：冻结案例、运行计划与对账（准备完成，未执行）

第六轮把「真实模型验收」从一份文档变成可核对的算术与拒绝规则，仍然**一次模型调用也没有发生**：

- `docs/plans/2026-10-28-joint-real-model-cases.json`：20 个冻结案例（12 意图门 + 8 工具路径）、预算 manifest 与「执行前须由用户填妥」的参数清单。
- `scripts/evaluation/joint-plan.mjs`：`validateCases`（id 唯一、两条工作线分离、工具案例必须带已知 kind 与 targets、预算算术自洽）、`approvalBlockers`（列全 11 个必填项）、`buildRunPlan`（**未填齐就拒绝**，只给 40 条会话与每条一个证据槽）、`reconcileRun`（逐会话给出声明、成本、工具路径三条轴，未跑的会话记 GAP 而不是跳过）。
- 证据：`tests/unit/joint-plan.spec.ts` 7 条 PASS（含「校验本仓库实际发布的案例文件」与「仅含空白的字段视为未填」）；CLI 实跑 exit 2、`status=unauthorized`、`blockers=11`、`sessions=40`、`validation={cases:20,gate:12,tool:8,conversations:40,nominalGenerationCap:240}`（产物 `joint-plan-unauthorized.json`）。

仍未执行的部分与所需条件见 §2 的空表与 §11：模型/provider/生成参数/单价/各类上限必须由用户填妥并明确授权，之后才可跑第 40 条会话。

## 11. 剩余缺口与下一步的外部条件

1. **P4 剩余**：真实取消矩阵（断点 4 的真实进程、真实压缩重放）与「跨进程 resume 后的账本一致性」——需要整宿主（P5/T3）。
2. **T2 剩余**：用真实会话轨迹复核判读（当前是 fixture/demo 级证据）；需要能产生真实会话的环境。
3. **P3 路线决断**：三条路线的改动面与所需证据见[选项包](../plans/2026-10-28-intent-gate-ux-recovery-options.md)；路线 1（Client 面插件）已有[最小设计稿](../plans/2026-10-28-p3-route1-client-presentation-design.md)（新包 + 客户端平面装配 + 浏览器穿透，CLI/ACP 仍显示失败），路线 2 的精确规格改法见该文附录。选定后再改规格与实现，本文件不代为决定。
4. **P5/T3**：按[整宿主运行手册](../plans/2026-10-28-joint-host-acceptance-runbook.md)在允许嵌套进程与真实打包安装的环境（或用户授权的隔离宿主窗口）执行 §3 的 11 步，并另写当日验收报告；本机做不到的原因见 §8。
5. **P6/T4**：需要用户填写模型/provider/生成参数/价格/上限并授权执行；`joint-plan --approval` 会在填齐后才把计划标成 `ready`（`joint-rehearsal` 已用固定夹具干跑过整条采集→报告→对账流水线），本文件与清单/工具都不产生任何调用。

## 12. 完成度总表（工程范围内可做的事 vs 需外部条件的事）

这张表是最终报告骨架：左半是**在没有授权外部动作的前提下能做的**，全部有证据；右半写清每个未完项缺的**具体外部条件**，不含「以后再看」这类占位。

### 12.1 已闭合（有本轮证据）

| 项 | 结果 | 证据位置 |
|---|---|---|
| 基线身份（仓库/宿主/引擎/契约包/资产摘要） | 已冻结并对齐 | §2.1 |
| 规格契约（IG-B-03/05/06/07/14/15/16/17/18 修订，新增 19/20 与 IGB-AC-16/17/18） | 已修订 | §2.2 |
| ADR-0006 重新对齐（路线 A 证否、B 需 Client 面、C 记缺口） | 已修订 | §2.4 |
| 问题服务真实形状（callId/subCallId/toolCallId/user-question-reply） | 按源码取证 | §2.3 |
| persona 三选一决策 + 歧义规则（无内嵌案例、全英文）+ 提问专用程序 + 工具路径清单 | 实际 assembly 契约 5 条 PASS | §3 |
| 等待按问题身份与所属请求判定（含裸「继续」不解锁、错 id 不解锁、重启不复活） | seam 级 PASS | §4、§5.4 |
| 提问与业务动作分开（同程序后续业务派发被拒） | seam 级 PASS | §4.2、§4 用例 |
| 资源上限在生成未结束时生效并释放来源 | seam 级 PASS | §5.1、§5.2 |
| 四个断点的取消 + 三段成本账本 + 重读不重置 | seam 级 PASS | §5.2～§5.4 |
| 按任务目标判读（adoption / path / proven bypass / candidate / unknown + 稳定原因码） | fixture/artifact/CLI 三级 PASS | §6 |
| 判读接进证据提取器（一次运行三份证据，旧报告形状兼容） | 5 条用例 PASS | §6 |
| 门禁证据预检（host/surface）+ 候选表（四轴→一判定） | 18 条用例 PASS | §7、§9 |
| 套件分诊可复跑（本机能跑什么、为什么跑不到） | 脚本 + 表 | §8 |
| 冻结案例、预算 manifest、采集操作单、干跑演练 | 机器可读 + 演练一致 | §10 |
| **P3 呈现规则核心**（哪些结局可升级为「正在补全」、哪些绝不） | 已实现并有 7 条用例，含与门前缀的防漂移断言 | §9 P3 行、`tests/unit/intent-recovering-presentation.spec.ts` |
| 分层文档（验收/计划/ADR/规格/GLOSSARY/README/状态索引/**分层 README**） | 链接 0 broken；六个意图门/联合修复 spec 与六个只读核对工具已写进 [integration README](../../tests/integration/README.md) 与 [evaluation README](../../scripts/evaluation/README.md)（含「被测试导入的 .mjs 不带 shebang」这一既有规则的复核） | 本文件各节 |

### 12.2 未闭合（各自缺什么）

| 项 | 状态 | 缺的具体条件 |
|---|---|---|
| P3 请求层「恢复中」（FIX-08、IGB-AC-18） | **部分**（规则核心 PASS；浏览器接线 BLOCKED） | 已选定路线 1；剩下的是宿主 client 依赖 + `tsdown` 构建 + 浏览器穿透，三者都需要一个允许安装/构建的环境（本环境 `pnpm install` 与 `SetFileSecurityW` 均被拒） |
| P5/T3 整宿主与交付门禁（FIX-01～14 的宿主侧、TOOL-01～07） | BLOCKED | 一个允许子进程 + 允许打包安装的环境窗口（或用户授权的隔离宿主），跑[运行手册](../plans/2026-10-28-joint-host-acceptance-runbook.md) §3 的 11 步 |
| 浏览器呈现证据（P3、FIX-08 的「看不到 Failed」） | BLOCKED | 同上的浏览器环境；当前只有控制器帧证据 |
| P4 真实取消矩阵与压缩重放 | GAP | 同 P5/T3 的环境（seam 级四个断点已闭合） |
| T2 真实轨迹复核（TOOL-01/02/03/08 的真实证据） | GAP | 同 P5/T3 的环境 |
| P6/T4 语义与工具采用效果（40 条冻结对话） | GAP | 用户填 `approval.json` 的 11 项（模板 `scripts/evaluation/joint-approval.example.json`）并明确授权；之后按[采集操作单](../plans/2026-10-28-joint-evaluation-collection.md)执行 |
| T0 edit 写路径与默认编辑策略回归 | BLOCKED（环境） | 允许 `SetFileSecurityW` 的文件系统（本沙箱拒绝，见 §8） |

### 12.3 一句话结论

**工程范围内能闭合的都已闭合且有证据；剩下四项缺口不是代码问题，而是三种外部条件**：一条 P3 路线选择、一个可跑门禁的环境窗口、一份模型与预算授权。

逐条规格的落点与检查见 §13 的追溯矩阵（12 个 IG-B 项 + TOOL-02/04/05，行号取自当前工作树并已逐条核对）；两行标为 BLOCKED/部分的，正是上表 12.2 里等外部条件的那两项。

## 13. 规格 ↔ 实现 ↔ 测试 追溯矩阵（第 17 轮，逐条核对过行号）

每一行都能指回产出点与检查；状态只有三种：**满足（本层）**、**部分（写明缺什么）**、**未满足（BLOCKED）**。行号取自本轮工作树，改动后需同步。

| 规格项 | 实现产出点 | 检查 | 状态 |
|---|---|---|---|
| **IG-B-03** 歧义是正常交互，不是输入错误 | `presets/ptc-hashline/personas/orchestrator.md` Phase 0（三选一决策 + 歧义规则；无内嵌案例、全英文） | `persona-intent-gate-contract.spec.ts`：三选一决策 + 歧义规则 + 「不得出现中文/场景粘贴」断言 | 满足（提示层；语义效果属 P6） |
| **IG-B-05** 请求层不把失配当结论 | 失败码与文案在 watchdog；呈现规则核心已实现（`presets/ptc-hashline/client/presentation.mjs`：只把两个声明码+紧随的修复通知升级为"正在补全"，其余一律保持失败） | `tests/unit/intent-recovering-presentation.spec.ts` 7 条（含拒绝陈旧/跨 turn 升级、文案无失败词、前缀与码表与门一致） | **部分**：规则已实现并验证；浏览器半（定义+渲染器+locale）因缺宿主 client 依赖与构建 BLOCKED |
| **IG-B-06** 取消后排队中的修复与续步零执行 | `intent-gate-watchdog.mjs:1157`（aborted turn 清阶段）、`:1192`（turn-stopping 的 abort 守卫） | P4 段：取消后不打开修复、已中止 turn 不投递续步 | 满足（seam） |
| **IG-B-07** 提问走插件可判读的正式路径 | `:305`（`user-question-reply` 按 callId 结算）；插件消息永不当作答案 | `intent-gate-request-scope`：宿主答案一律要求声明、选项名叫「继续」也按答案处理 | 满足（seam） |
| **IG-B-14** 待答状态按问题身份 + 所属请求保存 | `:860`（`settleQuestion`）、`:920`（记录问题）、`:890`（实质输入开新请求）、`:222`（`awaitingAnswer`） | 三个 reload 用例（问题、预算、断点 3 的真实重启） | 满足（seam） |
| **IG-B-15** 上限在生成未结束时生效并释放来源 | `:1345`（deadline 与来源竞争）、`:1370`（`source.return()`，不 await）、`:1381`（在 assemble 之前判定） | P4 段「停滞适配器在上限处停止」：零发布、来源 return 被调 1 次、不花修复 | 满足（seam） |
| **IG-B-16** 只有该问题自己的答案能结束等待 | `:860` + `:236`（裸形式不新开请求）+ 错 id/陈旧结算不改状态 | 澄清等待 9 条：裸「继续」不解锁、错 callId 不解锁、独立请求可推进且原问题仍在 | 满足（seam） |
| **IG-B-17** 续步后仍有未解歧义则先澄清 | `orchestrator.md:30`（等待语义）+ `:21`（缺事实先问） | `persona-intent-gate-contract`：提问专用程序 + 等待语义 | 部分（提示层；无可机械验证的「续步后必须澄清」守卫） |
| **IG-B-18** 问题阶段不计修复、不另给预算 | 预算只由 `REPAIR_NOTICE_PREFIX` 计；`:266`（账本按阶段分开） | 账本 5 条 + P4 段「只有 1 条修复通知」 | 满足（seam） |
| **IG-B-19** 提问与业务动作分开 | `:1232`（`tools/pre-execute` 拒同程序后续业务派发） | 澄清等待段的 IG-B-19 用例（拒 read、允许再问、另一根调用允许） | 满足（seam） |
| **IG-B-20** 请求层呈现五档互不冒充 | 三档已有（澄清正常、声明专用修复、协议暂停）；「恢复中」缺失 | 声明/暂停文案单测；「恢复中」无 | **部分**（P3 BLOCKED 的那一档） |
| **TOOL-02/04/05** 目标文件真的走适用路径、旁路与 unknown 分得清 | `scripts/tool-usage-judgement.mjs`（adoption/path/provenBypass/candidate/unknown + 稳定原因码） | 16 条 unit + 4 条 artifact + 5 条提取器接线 | 满足（fixture/artifact；真实轨迹 GAP） |

**怎么读这张表**：第 3 列没有「部分」或「未满足」的行，结论都建立在**可重跑的命令**上（见 §7）；两行写着 BLOCKED 的，正是 §12.2 里需要外部条件的那两项（P3 路线决断 + 整宿主环境）。
